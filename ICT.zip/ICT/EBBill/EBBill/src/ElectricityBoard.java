import java.util.*;
public class ElectricityBoard
{
  
    
    //write the required business logic methods as expected in the question description
    
    public void addBill(List<ElectricityBill> billList)
    {
        //fill your code here

    }
    
    public List<ElectricityBill> generateBill(String filePath) 
    {
        //fill your code here
    	
    }
    public boolean validate(String consumerNumber) throws InvalidConsumerNumberException
	{
    		//fill your code here
    		

	}

    
}
