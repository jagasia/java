import java.sql.Connection;

public class DBHandler {

	//Write the required business logic as expected in the question description
	public Connection establishConnection() {

		//fill the code

	}
}
